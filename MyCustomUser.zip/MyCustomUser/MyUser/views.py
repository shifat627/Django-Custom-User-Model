from django.shortcuts import render
from knox.auth import AuthToken
from django.contrib.auth import authenticate
from rest_framework.decorators import api_view,permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework import status
from rest_framework.response import Response
from .serializer import UserInfo,LoggedUser
from rest_framework.request import Request
from django.core.exceptions import ObjectDoesNotExist
# Create your views here.

@api_view(['POST',])
def Login(request):

    if(request.method == 'POST'):
        user = authenticate(email = request.POST.get('username',None),password = request.POST.get('password',None))
        if not user:
            return Response(status=status.HTTP_400_BAD_REQUEST)
        token = AuthToken.objects.create(user=user)
        return Response({'token':token[1]},status=status.HTTP_200_OK)
    return Response(status=status.HTTP_204_NO_CONTENT)

@api_view(['GET',])
@permission_classes([IsAuthenticated])
def Logout(request):
    request.auth.delete()
    return Response(status=status.HTTP_202_ACCEPTED)

@api_view(['GET',])
@permission_classes([IsAuthenticated])
def Whoami(request):
    info = UserInfo(request.user)
    return Response(info.data)


@api_view(['GET',])
@permission_classes([IsAuthenticated])
def ListLoggedDevice(request : Request):
    logged_user = AuthToken.objects.filter(user__exact=request.user)
    logged_user = logged_user.exclude(pk__exact=request.auth.pk)
    return Response(LoggedUser(logged_user,many=True).data)

@api_view(['POST',])
@permission_classes([IsAuthenticated])
def RemoteLogout(request : Request):
    pk = request.POST.get('pk')
    try:
        token = AuthToken.objects.get(pk=pk)
        token.delete()
        return Response(status=status.HTTP_200_OK)
    except ObjectDoesNotExist as Err:
        return Response({'details':str(Err)},status=status.HTTP_400_BAD_REQUEST)