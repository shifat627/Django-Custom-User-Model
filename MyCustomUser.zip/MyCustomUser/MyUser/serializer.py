from rest_framework import serializers
from django.contrib.auth import get_user_model
from knox.auth import AuthToken


class UserInfo(serializers.ModelSerializer):
    class Meta:
        model = get_user_model()
        fields = ['username','email','is_superuser','last_login','phone']

class LoggedUser(serializers.ModelSerializer):
    class Meta:
        model = AuthToken
        fields = ['pk','created','expiry']