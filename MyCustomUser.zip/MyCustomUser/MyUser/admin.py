from django.contrib import admin
from django import forms
from django.contrib.auth.admin import UserAdmin
from .models import MyOwnUser
from django.contrib.auth.forms import AdminPasswordChangeForm
# Register your models here.


class UserCreationForm(forms.ModelForm):
    Password = forms.CharField(label='Password:',widget=forms.PasswordInput)
    Password2 = forms.CharField(label='Confirm Password:',widget=forms.PasswordInput)
    class Meta:
        model = MyOwnUser
        fields = ['email','username','phone','is_active','is_staff','is_superuser']
        labels = {
            'email' : 'Email Address: ',
            'username' : 'Your Name: ',
            'phone':'Phone Number',
            'is_active':'State',
            'is_staff':'Can User Log in Django Admin',
            'is_superuser':'Superuser'
        }

        help_texts = {
            'email' : 'This will used to login',
            'is_superuser':'Has User superuser rights?'
        }

    def clean_Password2(self):
        if self.cleaned_data['Password'] != self.cleaned_data['Password2'] :
            raise forms.ValidationError('Password Does not Matched')

        return self.cleaned_data['Password2']
    
    def save(self, commit=False):
        user = super().save(commit=commit)
        user.set_password(self.cleaned_data['Password2'])
        
        if(commit):
            user.save()
        return user


class UserChangeForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super(UserChangeForm, self).__init__(*args, **kwargs)
        self.fields['password'].disabled = True
    
    class Meta:
        model = MyOwnUser
        fields = ['email','username','phone','is_active','is_staff','is_superuser']
        labels = {
            'email' : 'Email Address: ',
            'username' : 'Your Name: ',
            'phone':'Phone Number',
            'is_active':'State',
            'is_staff':'Can User Log in Django Admin',
            'is_superuser':'Superuser'
        }

        help_texts = {
            'email' : 'This will used to login',
            'is_superuser':'Has User superuser rights?'
        }
        
        
    def save(self, commit=True):
        return super().save(commit=commit)

class MyAdmin(UserAdmin):
    
    form = UserChangeForm # To Change User
    add_form = UserCreationForm # to Create New User (Used When user in created)
    model = MyOwnUser
    
    list_display = ('email','username','is_staff','is_superuser')
    list_filter = ('is_active',)

    search_fields = ('email','username',)

    #TO Show Fields of UserChangeForm while viewing or changing user (Help MyAdmin To Create its own form by providing field name from UserChangeForm.Then it will use UserChangeForm to save modified data of user)
    fieldsets = (
        ('Basic Info',{'fields':('email','password')}),
        ('Personal Info',{'fields':('username','phone')}),
        ('Permissions',{'fields':('is_staff','is_active','is_superuser','groups','user_permissions')}),
    )

    #To Show Fields of UserCreationForm while creating user (Help MyAdmin To Create its own form by providing field name from UserCreationForm.Then it will use UserCreationForm to save New user)
    add_fieldsets=((None, {
            'classes': ('wide',),
            'fields': ('email','Password','Password2','username','phone','is_active','is_staff','is_superuser')}
        ),)
        
admin.site.register(MyOwnUser,MyAdmin)